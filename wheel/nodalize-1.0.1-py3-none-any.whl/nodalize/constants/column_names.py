"""Hard-coded column names for data frames."""

BATCH_ID = "BatchId"
DATA_DATE = "DataDate"
INSERTED_DATETIME = "InsertedDatetime"
