"""Sub-module containing definitions for calculators."""
