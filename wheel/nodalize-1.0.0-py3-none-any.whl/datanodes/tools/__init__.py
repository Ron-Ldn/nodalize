"""Common tools for the project."""
