"""Custom types."""


class Symbol:
    """Symbol type (string with limited number of values)."""

    pass
