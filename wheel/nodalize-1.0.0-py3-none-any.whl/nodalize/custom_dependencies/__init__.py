"""Custom classes deriving from DependencyDefinition."""
