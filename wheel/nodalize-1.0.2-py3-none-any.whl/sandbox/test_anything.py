from nodalize.constants import column_names

column_names.DATA_DATE = "MyDate"


