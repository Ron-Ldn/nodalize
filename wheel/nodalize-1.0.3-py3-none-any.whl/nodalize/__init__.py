"""
nodalize package.

See https://github.com/Ron-Ldn/nodalize for user guides and examples.
"""
